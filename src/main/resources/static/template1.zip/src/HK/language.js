/**
 * 
 */

var languagePackage={
   'input_username':'请正确录入用户名',                     
   'input_password':'请正确录入密码',                  
   'password_not_equal':'密码不一致',                  
   'input_cashName':'请录入真实姓名',                  
   'input_phone':'请正确录入电话号码',                  
   'input_captcha':'请输入验证码',                 
   'captcha_error':'验证码错误',
   'exists_accountno':'用户名已经存在',
   'register_error':'注册失败'
}
