/**
 * Created by Ly on 2016/10/28.
 */

// 切换图标
var wallet = $("#nav-list #nav-wallet");
if(wallet.is(".active")){
	$(".active .icon .bar-img").attr("src","../img/icon/wallet_active.png");
}




