/**
 * Created by Ly on 2016/11/07.
 */

// 获取活动详情图片
$(".activity-img img").attr("src",getUrlParam('remark'));